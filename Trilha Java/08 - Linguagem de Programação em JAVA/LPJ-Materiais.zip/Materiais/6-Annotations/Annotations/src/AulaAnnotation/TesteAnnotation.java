package AulaAnnotation;

@AnnotationInformacao (
		autor = "Marcio Schoenfelder",
		aulaEADNumero = 2,
		website = "https://www.proway.com.br"
		)
public class TesteAnnotation {

	public static void main(String[] args) {
		

	}

}
