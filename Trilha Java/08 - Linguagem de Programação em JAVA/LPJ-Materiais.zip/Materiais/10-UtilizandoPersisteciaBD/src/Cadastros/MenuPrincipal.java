package Cadastros;

public class MenuPrincipal {

	public static void main(String[] args) {
		

	}

}
