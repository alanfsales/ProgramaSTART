package Interfaces;

public interface Animal {
	public void animalSom();
	public void animalComer();
}