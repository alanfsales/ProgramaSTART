package Interfaces;

public class InterfaceUso {

	public static void main(String[] args) {
		Animal animal = new Bovino();
		animal.animalSom();
		animal.animalComer();
	}
}